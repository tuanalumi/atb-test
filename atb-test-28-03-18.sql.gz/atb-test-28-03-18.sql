# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.21)
# Database: atb-test
# Generation Time: 2018-03-28 01:51:53 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table token
# ------------------------------------------------------------

DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `valid_until` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;

INSERT INTO `token` (`id`, `token`, `user_id`, `valid_until`)
VALUES
	(2,'5XV1ATN73REZYWTD6K7I2PTINC8V3POSTQXOYC6DK73SAFZWJZEWJR8NCIUVSNC8',6,'2018-03-23 15:26:49');

/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `email`, `password`, `name`, `address`, `tel`, `age`)
VALUES
	(3,'george10@kuvalis.org','$2y$10$LNhVRs4Fj6iBIPd9RN0h2eNMN6d.LAnIYsjMLTpcwk.ArmIWyHHFG','Lavina Kreiger','658 Moore Parkway Apt. 948\nEast Ross, NM 29560-8426','1-770-690-1967 x6942',7),
	(4,'edyth.pfeffer@stark.org','$2y$10$ul8Q1TtpKBfh9j0klvxPNu3.EmvT4T0ZXJIrYMMp2//sxb3MkhZJC','Kian Dibbert','3869 Beatty Ville Suite 104\nPort Alvera, TX 48549','672-917-3864 x68848',2),
	(5,'gottlieb.jordane@nader.net','$2y$10$XIiQVN9eoEMACyZoCVaG5eSyv5SKKAm7GhtoKdJE9fzMPY3uDfQr.','Dr. Alfonso Harris V','59885 Koby Green Apt. 213\nHaleymouth, VT 64786','373.938.7549 x07023',7),
	(6,'hayes.gage@gmail.com','$2y$10$mCDv/cL7.k89O4rm3fUgb./j9y7DuY5wJ73Qp1fpi6RZ/E0MUUf7a','10','733 Jakob Circle Suite 629\nLangworthfort, ID 47532-1147','+1302458824141',1),
	(7,'darius.west@wunsch.com','$2y$10$wsNmmtghib4BkQug1ZSA8um.Eu225ujoadaZ4Br4iGb29SQSKAx6O','Verda Mante V','730 Schiller Lodge Apt. 182\nGeraldineview, CO 06426-1074','+9039148885181',1);

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
